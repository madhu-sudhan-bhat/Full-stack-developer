module.exports = {
    mongoURI:
        'mongodb+srv://user:9w7HVR6z77UujXYQ@cluster0-n4wm7.gcp.mongodb.net/test?retryWrites=true&w=majority',
    secretOrKey: 'secret',
};
